#!/usr/bin/python
# -*- coding:utf-8 -*-

import sys
import time
import smbus

# I2C address of the device
ADDR				= 0x48

# ADS7830 Command Set
ADS7830_CMD_SD_DIFF					= 0x00 # Differential Inputs
ADS7830_CMD_SD_SINGLE				= 0x80 # Single-Ended Inputs
ADS7830_CMD_DIFF_CHANNEL_0_1		= 0x00 # +IN = CH0, -IN = CH1
ADS7830_CMD_DIFF_CHANNEL_2_3		= 0x10 # +IN = CH2, -IN = CH3
ADS7830_CMD_DIFF_CHANNEL_4_5		= 0x20 # +IN = CH4, -IN = CH5
ADS7830_CMD_DIFF_CHANNEL_6_7		= 0x30 # +IN = CH6, -IN = CH7
ADS7830_CMD_DIFF_CHANNEL_1_0		= 0x40 # +IN = CH1, -IN = CH0
ADS7830_CMD_DIFF_CHANNEL_3_2		= 0x50 # +IN = CH3, -IN = CH2
ADS7830_CMD_DIFF_CHANNEL_5_4		= 0x60 # +IN = CH5, -IN = CH4
ADS7830_CMD_DIFF_CHANNEL_7_6		= 0x70 # +IN = CH7, -IN = CH6
ADS7830_CMD_SNGL_CHANNEL_0			= 0x00 # +IN = CH0, -IN = GND
ADS7830_CMD_SNGL_CHANNEL_1			= 0x10 # +IN = CH1, -IN = GND
ADS7830_CMD_SNGL_CHANNEL_2			= 0x20 # +IN = CH2, -IN = GND
ADS7830_CMD_SNGL_CHANNEL_3			= 0x30 # +IN = CH3, -IN = GND
ADS7830_CMD_SNGL_CHANNEL_4			= 0x40 # +IN = CH4, -IN = GND
ADS7830_CMD_SNGL_CHANNEL_5			= 0x50 # +IN = CH5, -IN = GND
ADS7830_CMD_SNGL_CHANNEL_6			= 0x60 # +IN = CH6, -IN = GND
ADS7830_CMD_SNGL_CHANNEL_7			= 0x70 # +IN = CH7, -IN = GND
ADS7830_CMD_PD_POWER_DOWN			= 0x00 # Power Down Between A/D Converter Conversions
ADS7830_CMD_PD_REF_OFF				= 0x04 # Internal Reference OFF and A/D Converter ON
ADS7830_CMD_PD_REF_ON				= 0x08 # Internal Reference ON and A/D Converter OFF
ADS7830_CMD_PD_REF_ON_AD_ON			= 0x0C # Internal Reference ON and A/D Converter ON

CMD_SINGLE = (0x84, 0xc4, 0x94, 0xd4, 0xa4, 0xe4, 0xb4, 0xf4)

class ADS7830:
	def __init__(self, address=ADDR):
		self.i2c = smbus.SMBus(1)
		self.address = address
		self.i2c.write_byte(ADDR, 0x04) #ADS7830_CMD_PD_REF_OFF
        
	def set_SINGLEchannel(self, channel):
		mode = ADS7830_CMD_SD_SINGLE
		if channel == 0:
			COMMAND_SET = (mode | ADS7830_CMD_SNGL_CHANNEL_0)
		elif channel == 1:
			COMMAND_SET = (mode | ADS7830_CMD_SNGL_CHANNEL_1)
		elif channel == 2:
			COMMAND_SET = (mode | ADS7830_CMD_SNGL_CHANNEL_2)
		elif channel == 3:
			COMMAND_SET = (mode | ADS7830_CMD_SNGL_CHANNEL_3)
		elif channel == 4:
			COMMAND_SET = (mode | ADS7830_CMD_SNGL_CHANNEL_4)
		elif channel == 5:
			COMMAND_SET = (mode | ADS7830_CMD_SNGL_CHANNEL_5)
		elif channel == 6:
			COMMAND_SET = (mode | ADS7830_CMD_SNGL_CHANNEL_6)
		elif channel == 7:
			COMMAND_SET = (mode | ADS7830_CMD_SNGL_CHANNEL_7)
		
		self.i2c.write_byte(self.address, COMMAND_SET)
        
	def set_DIFFchannel(self, channel):
		mode = ADS7830_CMD_SD_DIFF
		"""Select the Command data from the given provided value above"""
		if channel == 0:
			COMMAND_SET = (mode | ADS7830_CMD_DIFF_CHANNEL_0_1)
		elif channel == 1:
			COMMAND_SET = (mode | ADS7830_CMD_DIFF_CHANNEL_2_3)
		elif channel == 2:
			COMMAND_SET = (mode | ADS7830_CMD_DIFF_CHANNEL_4_5)
		elif channel == 3:
			COMMAND_SET = (mode | ADS7830_CMD_DIFF_CHANNEL_6_7)
		elif channel == 4:
			COMMAND_SET = (mode | ADS7830_CMD_DIFF_CHANNEL_1_0)
		elif channel == 5:
			COMMAND_SET = (mode | ADS7830_CMD_DIFF_CHANNEL_3_2)
		elif channel == 6:
			COMMAND_SET = (mode | ADS7830_CMD_DIFF_CHANNEL_5_4)
		elif channel == 7:
			COMMAND_SET = (mode | ADS7830_CMD_DIFF_CHANNEL_7_6)
		
		self.i2c.write_byte(self.address, COMMAND_SET)
	
	def read_adc(self, channel):
		self.i2c.write_byte(ADDR, CMD_SINGLE[channel])
		"""Read data back from the device address, 1 byte"""
		data = self.i2c.read_byte(self.address)
		adc = data
		
		return adc
        
	def read_All(self):
		listadc = [0, 0, 0, 0, 0, 0, 0, 0]
		for i in range(0, 8):
			self.i2c.write_byte(ADDR, CMD_SINGLE[i])
			"""Read data back from the device address, 1 byte"""
			adc = self.i2c.read_byte(self.address)
			listadc[i] = (adc/255)*3.3
		return listadc  

if __name__ == '__main__':
    ads = ADS7830()
    time.sleep(1)
    try:
        while True:
            # ch = ads.read_adc(0)
            # print("CH0 ADC: %.2fV" %((ch/256)*3.3))
            adc = ads.read_All()
            print("ADC:", adc)
           
            
            time.sleep(1)

    except KeyboardInterrupt:
        exit()
